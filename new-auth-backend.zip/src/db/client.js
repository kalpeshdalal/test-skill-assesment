// src/db/client.js
const { PrismaClient } = require('@prisma/client');
const { PrismaPg } = require('@prisma/adapter-pg');
const { Pool } = require('pg');
const config = require('../config/config');
const logger = require('../config/logger');

const globalForPrisma = global;

const pool = new Pool({ 
  connectionString: config.databaseUrl,
  max: 10 
});

const adapter = new PrismaPg(pool);

// 1. Create the base client
const basePrisma = new PrismaClient({
  adapter,
  log: config.env === 'development' ? ['query', 'error', 'warn'] : ['error'],
});

// 2. Extend the client to fix the Driver Adapter error handling globally
const prisma = basePrisma.$extends({
  query: {
    $allModels: {
      async $allOperations({ model, operation, args, query }) {
        try {
          return await query(args);
        } catch (error) {
          // If meta.target is missing in P2002, try to parse it from the message
          if (error.code === 'P2002' && !error.meta?.target) {
             const targetMatch = error.message.match(/Unique constraint failed on the fields: \(`(.*?)`\)/);
             if (targetMatch && targetMatch[1]) {
               // Assign the missing target back to the error object so services can read it
               error.meta = { ...error.meta, target: [targetMatch[1]] };
             }
          }
          throw error;
        }
      },
    },
  },
});

if (config.env !== 'production') globalForPrisma.prisma = prisma;

const connectDB = async () => {
  try {
    await basePrisma.$connect();
    logger.info('PostgreSQL connection established via Prisma Driver Adapter.');
  } catch (error) {
    logger.error('Unable to connect to the database:', error);
    process.exit(1);
  }
};

module.exports = {
  prisma,
  connectDB
};