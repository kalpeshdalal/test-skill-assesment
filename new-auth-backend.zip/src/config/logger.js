const winston = require('winston');
const config = require('./config');
const path = require('path');

// Custom error formatting
const enumerateErrorFormat = winston.format((info) => {
  if (info instanceof Error) {
    Object.assign(info, { message: info.stack });
  }
  return info;
});

const logFilename = path.join(__dirname, '../../logs/app.log'); 
const logLevel = config.env === 'development' ? 'debug' : 'info';

const logger = winston.createLogger({
  level: logLevel,
  format: winston.format.combine(
    winston.format.timestamp({ format: 'YYYY-MM-DD HH:mm:ss' }),
    enumerateErrorFormat(),
    config.env === 'development' ? winston.format.colorize() : winston.format.uncolorize(),
    winston.format.splat(),
    winston.format.printf(({ timestamp, level, message, ...metadata }) => {
      const metaString = Object.keys(metadata).length
        ? `\n${JSON.stringify(metadata, null, 2)}` 
        : '';
      return `[${timestamp}] ${level}: ${message} ${metaString}`;
    })
  ),
  transports: [
    new winston.transports.Console({
      stderrLevels: ['error'],
    }),
  ],
});

// DEV MODE ONLY: Write to local file for easy debugging
// In Production, we rely on the Console transport (stdout) for CloudWatch/Datadog to pick up
if (config.env === 'development') {
  logger.add(new winston.transports.File({ 
    filename: logFilename,
    maxsize: 5242880, // 5MB
    maxFiles: 5,
  }));
}

module.exports = logger;