const { Strategy: JwtStrategy, ExtractJwt } = require("passport-jwt");
const config = require("./config");
const { tokenTypes } = require("./enums");
const { prisma } = require("../db/client");
const tokenService = require("../services/token.service"); 
const { extractToken } = require("../utilities/tokenUtils");

const jwtOptions = {
  secretOrKey: config.jwt.secret,
  jwtFromRequest: ExtractJwt.fromAuthHeaderAsBearerToken(),
  passReqToCallback: true, 
};

const jwtVerify = async (req, payload, done) => {
  try {
    if (payload.type !== tokenTypes.ACCESS) {
      throw new Error("Invalid token type");
    }

    const rawToken = extractToken(req);
    const isBlacklisted = await tokenService.isTokenBlacklisted(rawToken);
    
    if (isBlacklisted) {
      return done(null, false); // Reject immediately
    }
    
    // Check User
    const user = await prisma.user.findUnique({
      where: { id: payload.sub },
    });

    if (!user || user.isDeleted || !user.isActive) {
      return done(null, false);
    }

    done(null, user);
  } catch (error) {
    done(error, false);
  }
};

const jwtStrategy = new JwtStrategy(jwtOptions, jwtVerify);

module.exports = { jwtStrategy };