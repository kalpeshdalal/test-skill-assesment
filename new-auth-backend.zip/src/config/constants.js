const responseMessages = {
  auth: {
    LOGIN_SUCCESS: 'Login successful',
    LOGOUT_SUCCESS: 'Logout successful',
    LOGOUT_ALL_SUCCESS: 'Logged out from all devices successfully',
    REFRESH_SUCCESS: 'Token refreshed successfully',
    INVALID_TOKEN: 'Invalid or expired refresh token',
    SESSION_EXPIRED: 'Session has expired',
    UNAUTHORIZED: 'Unauthorized access',
    USER_REGISTERED: 'User registered successfully',
    INCORRECT_EMAIL_PASSWORD: "Incorrect email or password",
    PLEASE_AUTHENTICATE: "Please Authenticate",
    MOBILE_ALREADY_REGISTERED: "Mobile Number is already registered.",
    EMAIL_ALREADY_REGISTERED: "Email is already registered",
    SESSIONS_FETCHED: 'Active sessions retrieved successfully',
    SESSION_REVOKED: 'Session revoked successfully',
  },
  rateLimit: {
    GLOBAL: 'Too many requests, please try again later.',
    AUTH_STRICT: 'Too many login attempts, please try again in 15 minutes.',
  },
  server: {
    INTERNAL_ERROR: 'Internal Server Error',
  }
};

const auditActions = {
  AUTH_LOGIN: 'AUTH_LOGIN',
  AUTH_LOGOUT: 'AUTH_LOGOUT',
  AUTH_REFRESH: 'AUTH_REFRESH',
  AUTH_FAILED: 'AUTH_FAILED',
  SENSITIVE_UPDATE: 'SENSITIVE_UPDATE', 
};

const systemConfig = {
  TOKEN_LENGTH: 40,        
  HASH_ALGORITHM: 'sha256' 
};

module.exports = {
  responseMessages,
  auditActions,
  systemConfig,
};