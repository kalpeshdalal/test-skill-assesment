const crypto = require('crypto');
const httpStatus = require('http-status');
const { prisma } = require('../db/client');
const ApiError = require('../utilities/apiErrors');
const config = require('../config/config');
const { responseMessages, auditActions, systemConfig } = require('../config/constants');
const jwt = require('jsonwebtoken');
const { tokenTypes } = require('../config/enums');

const generateOpaqueToken = () => {
  return crypto.randomBytes(systemConfig.TOKEN_LENGTH).toString('hex');
};

const hashToken = (token) => {
  return crypto.createHash(systemConfig.HASH_ALGORITHM).update(token).digest('hex');
};

const generateAccessToken = (userId) => {
  const payload = {
    sub: userId,
    type: tokenTypes.ACCESS,
    iat: Math.floor(Date.now() / 1000),
  };
  return jwt.sign(payload, config.jwt.secret, {
    expiresIn: `${config.jwt.accessExpirationMinutes}m`,
  });
};

const createSecureSession = async (userId, ipAddress, userAgent) => {
  const refreshToken = generateOpaqueToken();
  const refreshTokenHash = hashToken(refreshToken);

  const accessToken = generateAccessToken(userId);
  const accessTokenHash = hashToken(accessToken);

  const expiresAt = new Date();
  expiresAt.setDate(expiresAt.getDate() + config.jwt.refreshExpirationDays);

  await prisma.$transaction(async (tx) => {
    await tx.token.create({
      data: {
        token: refreshTokenHash,
        userId: userId,
        type: tokenTypes.REFRESH,
        expires: expiresAt,
        blacklisted: false,
        ipAddress,
        userAgent,
        accessTokenHash: accessTokenHash,
      },
    });

    await tx.auditLog.create({
      data: {
        userId,
        action: auditActions.AUTH_LOGIN,
        ipAddress,
        userAgent,
        metadata: { method: 'password' }
      },
    });

    await tx.user.update({
      where: { id: userId },
      data: { lastLoginAt: new Date() }
    });
  });

  return { refreshToken, accessToken };
};

const rotateRefreshToken = async (rawRefreshToken, ipAddress, userAgent) => {
  const hashedToken = hashToken(rawRefreshToken);

  const tokenDoc = await prisma.token.findFirst({
    where: {
      token: hashedToken,
      type: tokenTypes.REFRESH,
      blacklisted: false
    },
  });

  if (!tokenDoc) {
    throw new ApiError(httpStatus.UNAUTHORIZED, responseMessages.auth.INVALID_TOKEN);
  }

  if (new Date() > tokenDoc.expires) {
    await prisma.token.delete({ where: { id: tokenDoc.id } });
    throw new ApiError(httpStatus.UNAUTHORIZED, responseMessages.auth.SESSION_EXPIRED);
  }

  const newRefreshToken = generateOpaqueToken();
  const newHash = hashToken(newRefreshToken);

  const newAccessToken = generateAccessToken(tokenDoc.userId);
  const newAccessTokenHash = hashToken(newAccessToken);

  const newExpires = new Date();
  newExpires.setDate(newExpires.getDate() + config.jwt.refreshExpirationDays);

  await prisma.$transaction(async (tx) => {
    const deletedToken = await tx.token.deleteMany({
      where: { id: tokenDoc.id }
    });

    if (deletedToken.count === 0) {
      throw new ApiError(httpStatus.UNAUTHORIZED, responseMessages.auth.INVALID_TOKEN);
    }

    await tx.token.create({
      data: {
        token: newHash,
        userId: tokenDoc.userId,
        type: tokenTypes.REFRESH,
        expires: newExpires,
        blacklisted: false,
        ipAddress,
        userAgent,
        accessTokenHash: newAccessTokenHash,
      },
    });

    await tx.auditLog.create({
      data: { userId: tokenDoc.userId, action: auditActions.AUTH_REFRESH, ipAddress, userAgent },
    });
  });

  return { newRefreshToken, accessToken: newAccessToken, userId: tokenDoc.userId };
};

const revokeRefreshTokens = async (refreshToken, ipAddress, userAgent) => {
  const hashedToken = hashToken(refreshToken);

  const tokenDoc = await prisma.token.findFirst({
    where: { token: hashedToken, type: tokenTypes.REFRESH }
  });

  if (tokenDoc) {
    await prisma.$transaction(async (tx) => {
      await tx.token.delete({ where: { id: tokenDoc.id } });
      await tx.auditLog.create({
        data: {
          userId: tokenDoc.userId,
          action: auditActions.AUTH_LOGOUT,
          ipAddress: ipAddress || 'unknown',
          userAgent: userAgent || 'unknown',
        },
      });
    });
  }
};

const blacklistToken = async (token, userId, expiresAt) => {
  const tokenHash = hashToken(token);
  await prisma.token.create({
    data: {
      token: tokenHash,
      userId: userId,
      type: tokenTypes.ACCESS,
      expires: expiresAt,
      blacklisted: true,
    },
  });
};

const isTokenBlacklisted = async (token) => {
  const tokenHash = hashToken(token);
  const blacklistedToken = await prisma.token.findFirst({
    where: { token: tokenHash, blacklisted: true },
  });
  return !!blacklistedToken;
};

/**
 * Revoke ALL sessions & Blacklist their Access Tokens
 */
const revokeAllUserSessions = async (userId, ipAddress, userAgent) => {
  await prisma.$transaction(async (tx) => {
    // 1. Find all active sessions to get their Access Token Hashes
    const sessions = await tx.token.findMany({
      where: {
        userId,
        type: tokenTypes.REFRESH,
      },
      select: { accessTokenHash: true }
    });

    // 2. Prepare Blacklist Entries
    // We set expiry to "now + access token life" to ensure they are killed
    const blacklistExpiry = new Date(Date.now() + config.jwt.accessExpirationMinutes * 60 * 1000);

    const blacklistEntries = sessions
      .filter(s => s.accessTokenHash)
      .map(s => ({
        token: s.accessTokenHash, // This is ALREADY hashed
        userId,
        type: tokenTypes.ACCESS,
        blacklisted: true,
        expires: blacklistExpiry,
      }));

    // 3. Bulk Insert into Blacklist
    if (blacklistEntries.length > 0) {
      await tx.token.createMany({
        data: blacklistEntries,
        skipDuplicates: true,
      });
    }

    // 4. Delete ALL sessions
    await tx.token.deleteMany({
      where: {
        userId,
        type: tokenTypes.REFRESH,
      },
    });

    // 5. Audit Log
    await tx.auditLog.create({
      data: {
        userId,
        action: auditActions.AUTH_LOGOUT,
        ipAddress: ipAddress || 'unknown',
        userAgent: userAgent || 'unknown',
        metadata: { type: 'ALL_DEVICES_LOGOUT' }
      }
    });
  });
};

module.exports = {
  createSecureSession,
  rotateRefreshToken,
  hashToken,
  generateAccessToken,
  revokeRefreshTokens,
  isTokenBlacklisted,
  blacklistToken,
  revokeAllUserSessions
};