const express = require('express');
const auth = require('../middlewares/auth');
const userController = require('../modules/users/controllers/getUserProfile.controller');
const getSessionController = require('../modules/users/controllers/getActiveSession.controller');
const revokeSessionController = require('../modules/users/controllers/revokeSession.controller');

const router = express.Router();

router.get('/me', auth(), userController.getProfile);

// Session Management
router.get('/me/sessions', auth(), getSessionController.getActiveSessions);
router.delete('/me/sessions/:sessionId', auth(), revokeSessionController.revokeSession);

module.exports = router;