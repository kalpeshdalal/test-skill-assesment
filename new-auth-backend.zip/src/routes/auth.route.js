const express = require('express');
const validate = require('../middlewares/validate');
const authValidation = require('../modules/auth/auth.validations');
const { authLimiter } = require('../middlewares/rateLimiter');
const auth = require('../middlewares/auth'); 

const registerController = require('../modules/auth/controllers/register.controller');
const loginController = require('../modules/auth/controllers/login.controller');
const logoutController = require('../modules/auth/controllers/logout.controller');
const refreshController = require('../modules/auth/controllers/refresh.controller');

const router = express.Router();

// Public Routes
router.post('/register', authLimiter, validate(authValidation.register), registerController.register);
router.post('/login', authLimiter, validate(authValidation.login), loginController.login);

// Authenticated/Token Routes
router.post('/logout', auth(), validate(authValidation.logout), logoutController.logout);
router.post('/refresh-tokens', validate(authValidation.refreshTokens), refreshController.refreshTokens);
// Logout All Devices 
router.post('/logout-all', auth(), logoutController.logoutAll);

module.exports = router;