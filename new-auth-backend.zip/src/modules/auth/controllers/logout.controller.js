const httpStatus = require('http-status');
const catchAsync = require('../../../utilities/catchAsync');
const logoutService = require('../services/logout.service');
const { responseMessages } = require('../../../config/constants');
const { getRefreshTokenCookieOptions } = require('../../../utilities/cookieOptions');
const sendResponse = require('../../../utilities/responseHandler');
const { extractToken } = require('../../../utilities/tokenUtils');
const pick = require('../../../utilities/pick');

const logout = catchAsync(async (req, res) => {
  const accessToken = extractToken(req);

  await logoutService.logoutUser(
    req.cookies.refreshToken,
    accessToken,
    req.ip,
    req.headers['user-agent']
  );

  const cookieOptions = getRefreshTokenCookieOptions();
  res.clearCookie('refreshToken', { ...cookieOptions, maxAge: 0 });

  sendResponse(res, httpStatus.OK, null, responseMessages.auth.LOGOUT_SUCCESS);
});

const logoutAll = catchAsync(async (req, res) => {
  // 1. Get User ID (Requires auth() middleware)
  const { id: userId } = pick(req.user, ['id']);
  
  // 2. Get Current Access Token
  const accessToken = extractToken(req);

  // 3. Call Service
  await logoutService.logoutAllDevices(
    userId,
    accessToken,
    req.ip,
    req.headers['user-agent']
  );

  // 4. Clear cookie
  const cookieOptions = getRefreshTokenCookieOptions();
  res.clearCookie('refreshToken', { ...cookieOptions, maxAge: 0 });

  sendResponse(res, httpStatus.OK, null, responseMessages.auth.LOGOUT_ALL_SUCCESS);
});

module.exports = {
  logout,
  logoutAll,
};