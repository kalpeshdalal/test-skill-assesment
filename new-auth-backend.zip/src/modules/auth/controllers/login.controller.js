const httpStatus = require('http-status');
const catchAsync = require('../../../utilities/catchAsync');
const pick = require('../../../utilities/pick');
const loginService = require('../services/login.service');
const { sendAuthResponse } = require('../services/auth.service'); 
const logger = require('../../../config/logger');
const { responseMessages } = require('../../../config/constants');

const login = catchAsync(async (req, res) => {
  const { email, password } = pick(req.body, ['email', 'password']);
  
  logger.info(`Login attempt for user: ${email}`);
  
  const user = await loginService.loginUserWithEmailAndPassword(email, password);
  
  await sendAuthResponse(req, res, user, httpStatus.OK, responseMessages.auth.LOGIN_SUCCESS);
});

module.exports = { login };