const httpStatus = require('http-status');
const tokenService = require('../../../services/token.service');
const ApiError = require('../../../utilities/apiErrors');
const { responseMessages } = require('../../../config/constants');

const refreshAuth = async (refreshToken, ipAddress, userAgent) => {
  if (!refreshToken) {
    throw new ApiError(httpStatus.UNAUTHORIZED, responseMessages.auth.PLEASE_AUTHENTICATE);
  }

  // Service returns everything we need
  const { accessToken, newRefreshToken } = await tokenService.rotateRefreshToken(
    refreshToken, 
    ipAddress, 
    userAgent
  );
  
  return { accessToken, newRefreshToken };
};

module.exports = { refreshAuth };