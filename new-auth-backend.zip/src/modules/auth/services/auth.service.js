const bcrypt = require('bcryptjs');
const httpStatus = require('http-status');
const tokenService = require('../../../services/token.service');
const { getRefreshTokenCookieOptions } = require('../../../utilities/cookieOptions');
const sendResponse = require('../../../utilities/responseHandler');

const hashPassword = async (password) => {
  return bcrypt.hash(password, 8);
};

const verifyPassword = async (password, hash) => {
  return bcrypt.compare(password, hash);
};

const sendAuthResponse = async (req, res, user, statusCode, message) => {
  const { refreshToken, accessToken } = await tokenService.createSecureSession(
    user.id, 
    req.ip, 
    req.headers['user-agent']
  );

  res.cookie('refreshToken', refreshToken, getRefreshTokenCookieOptions());

  sendResponse(res, statusCode, { user, accessToken }, message);
};

module.exports = {
  hashPassword,
  verifyPassword,
  sendAuthResponse
};