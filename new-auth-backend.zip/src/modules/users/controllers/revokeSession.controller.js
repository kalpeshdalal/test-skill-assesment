const httpStatus = require('http-status');
const catchAsync = require('../../../utilities/catchAsync');
const sendResponse = require('../../../utilities/responseHandler');
const revokeService = require('../services/revokeSession.service');
const pick = require('../../../utilities/pick');
const { responseMessages } = require('../../../config/constants');

const revokeSession = catchAsync(async (req, res) => {
  const { id: userId } = pick(req.user, ['id']);
  const { sessionId } = req.params;

  await revokeService.revokeSession(sessionId, userId);

  sendResponse(
    res,
    httpStatus.OK,
    null,
    responseMessages.auth.SESSION_REVOKED
  );
});

module.exports = {
  revokeSession,
};