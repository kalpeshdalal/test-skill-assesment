const httpStatus = require('http-status');
const { prisma } = require('../../../db/client');
const ApiError = require('../../../utilities/apiErrors');
const { tokenTypes } = require('../../../config/enums');

const revokeSession = async (sessionId, userId) => {
  const id = parseInt(sessionId, 10);
  if (isNaN(id)) throw new ApiError(httpStatus.BAD_REQUEST, 'Invalid Session ID');

  const session = await prisma.token.findUnique({
    where: { id },
  });

  if (!session) throw new ApiError(httpStatus.NOT_FOUND, 'Session not found');
  if (session.userId !== userId) throw new ApiError(httpStatus.FORBIDDEN, 'Forbidden');

  await prisma.$transaction(async (tx) => {
    // 1. IF the session has a linked Access Token Hash, Blacklist it!
    if (session.accessTokenHash) {
      
      // We set expiry to 1 hour from now (safe buffer since we don't store AT expiry)
      const estimatedExpiry = new Date();
      estimatedExpiry.setHours(estimatedExpiry.getHours() + 1); 

      await tx.token.create({
        data: {
          token: session.accessTokenHash, 
          userId: session.userId,
          type: tokenTypes.ACCESS,      // Type is now ACCESS
          blacklisted: true,            // Mark as blacklisted
          expires: estimatedExpiry,
        }
      });
    }

    // 2. Delete the Session (Refresh Token)
    await tx.token.delete({ where: { id } });
  });
};

module.exports = { revokeSession };