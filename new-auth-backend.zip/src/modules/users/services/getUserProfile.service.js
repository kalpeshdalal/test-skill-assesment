const httpStatus = require('http-status');
const { prisma } = require('../../../db/client');
const ApiError = require('../../../utilities/apiErrors');

/**
 * Get user by ID
 * @param {string} id
 * @returns {Promise<User>}
 */
const getUserById = async (id) => {
  const user = await prisma.user.findUnique({
    where: { id },
  });

  if (!user) {
    throw new ApiError(httpStatus.NOT_FOUND, 'User not found');
  }

  return user;
};

module.exports = {
  getUserById,
};