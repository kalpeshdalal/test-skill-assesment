const { prisma } = require('../../../db/client');
const { tokenTypes } = require('../../../config/enums');

/**
 * Get active sessions (Active REFRESH tokens)
 * @param {string} userId
 * @returns {Promise<Array>}
 */
const getUserActiveSessions = async (userId) => {
  const sessions = await prisma.token.findMany({
    where: {
      userId: userId,
      type: tokenTypes.REFRESH, 
      blacklisted: false,       
      expires: { gt: new Date() }, 
    },
    select: {
      id: true, 
      ipAddress: true,
      userAgent: true,
      expires: true, 
      createdAt: true,
    },
    orderBy: { createdAt: 'desc' },
  });

  return sessions;
};

module.exports = {
  getUserActiveSessions,
};