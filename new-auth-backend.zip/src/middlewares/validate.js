const Joi = require('joi');
const httpStatus = require('http-status');
const pick = require('../utilities/pick');
const ApiError = require('../utilities/apiErrors');

const validate = (schema) => (req, res, next) => {
  // 1. Pick only the relevant parts of the schema (params, query, body)
  const validSchema = pick(schema, ['params', 'query', 'body']);
  
  // 2. Pick the corresponding data from the request object
  const object = pick(req, Object.keys(validSchema));

  // 3. Compile and validate
  const { value, error } = Joi.compile(validSchema)
    .prefs({ errors: { label: 'key' }, abortEarly: false })
    .validate(object);

  if (error) {
    // Create a single error message string
    const errorMessage = error.details.map((details) => details.message).join(', ');
    return next(new ApiError(httpStatus.BAD_REQUEST, errorMessage));
  }

  // 4. Update req with the validated (and possibly type-converted) value
  Object.assign(req, value);
  return next();
};

module.exports = validate;