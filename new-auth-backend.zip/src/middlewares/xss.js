const xss = require('xss');

/**
 * Recursive function to sanitize objects/arrays/strings
 */
const sanitize = (data) => {
  if (!data) return data;
  
  if (typeof data === 'string') {
    return xss(data);
  }
  
  if (Array.isArray(data)) {
    return data.map(sanitize);
  }
  
  if (typeof data === 'object') {
    Object.keys(data).forEach((key) => {
      data[key] = sanitize(data[key]);
    });
  }
  
  return data;
};

const xssSanitizer = (req, res, next) => {
  if (req.body) sanitize(req.body);
  if (req.query) sanitize(req.query);
  if (req.params) sanitize(req.params);
  next();
};

module.exports = xssSanitizer;