const express = require('express');
// Import your individual route files here
// const authRoute = require('./auth.route');
// const userRoute = require('./user.route');

const router = express.Router();

const defaultRoutes = [
  // {
  //   path: '/auth',
  //   route: authRoute,
  // },
  // {
  //   path: '/users',
  //   route: userRoute,
  // },
];

defaultRoutes.forEach((route) => {
  router.use(route.path, route.route);
});

// Defines a health check route
router.get('/health', (req, res) => {
  res.send({ status: 'OK', timestamp: new Date() });
});

module.exports = router;