const { RateLimiterMemory } = require('rate-limiter-flexible');
const httpStatus = require('http-status');
const ApiError = require('../utilities/apiErrors');
const { responseMessages } = require('../config/constants'); 

const createLimiter = (points, duration, errorMessage) => {
  const limiter = new RateLimiterMemory({ points, duration });

  return (req, res, next) => {
    limiter.consume(req.ip)
      .then((rateLimiterRes) => {
        res.setHeader('X-RateLimit-Limit', points);
        res.setHeader('X-RateLimit-Remaining', rateLimiterRes.remainingPoints);
        res.setHeader('X-RateLimit-Reset', new Date(Date.now() + rateLimiterRes.msBeforeNext).toISOString());
        next();
      })
      .catch((rateLimiterRes) => {
        const retrySecs = Math.round(rateLimiterRes.msBeforeNext / 1000) || 1;
        res.setHeader('Retry-After', retrySecs);
        next(new ApiError(httpStatus.TOO_MANY_REQUESTS, errorMessage));
      });
  };
};

const globalLimiter = createLimiter(100, 300, responseMessages.rateLimit.GLOBAL);

const authLimiter = createLimiter(5, 15 * 60, responseMessages.rateLimit.AUTH_STRICT);

module.exports = {
  globalLimiter,
  authLimiter,
};