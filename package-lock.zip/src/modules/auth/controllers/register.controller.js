const httpStatus = require('http-status');
const catchAsync = require('../../../utilities/catchAsync'); 
const sendResponse = require('../../../utilities/responseHandler'); 
const pick = require('../../../utilities/pick'); 
const { getRefreshTokenCookieOptions } = require('../../../utilities/cookieOptions');
const tokenService = require('../../../services/token.service'); 
const registerService = require('../services/register.service');
const loginService = require('../services/login.service.js');
const logger = require('../../../config/logger'); 

const register = catchAsync(async (req, res) => {
  // Use pick to prevent mass-assignment vulnerabilities
  const userBody = pick(req.body, ['email', 'password', 'fullName', 'mobile', 'designation']);
  
  logger.debug(`Registering new user: ${userBody.email}`);

  // Business logic execution
  const user = await registerService.registerUser(userBody);
  
  // Token generation
  const accessToken = loginService.generateAccessToken(user.id);
  const refreshToken = await tokenService.createSecureSession(user.id, req.ip, req.headers['user-agent']);

  // Consistent cookie and response handling
  res.cookie('refreshToken', refreshToken, getRefreshTokenCookieOptions());
  sendResponse(res, httpStatus.CREATED, { user, accessToken }, 'User registered successfully');
});

module.exports = { register };