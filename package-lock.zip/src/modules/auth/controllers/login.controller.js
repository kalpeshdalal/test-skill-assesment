const httpStatus = require('http-status');
const catchAsync = require('../../../utilities/catchAsync');
const sendResponse = require('../../../utilities/responseHandler'); 
const pick = require('../../../utilities/pick'); 
const { getRefreshTokenCookieOptions } = require('../../../utilities/cookieOptions'); 
const tokenService = require('../../../services/token.service'); 
const loginService = require('../services/login.service');
const logger = require('../../../config/logger');

const login = catchAsync(async (req, res) => {
  const { email, password } = pick(req.body, ['email', 'password']);
  
  logger.info(`Login attempt for user: ${email}`);
  
  const user = await loginService.loginUserWithEmailAndPassword(email, password);
  const accessToken = tokenService.generateAccessToken(user.id);
  const refreshToken = await tokenService.createSecureSession(user.id, req.ip, req.headers['user-agent']);

  res.cookie('refreshToken', refreshToken, getRefreshTokenCookieOptions());
  sendResponse(res, httpStatus.OK, { user, accessToken }, 'Login successful');
});

module.exports = { login };