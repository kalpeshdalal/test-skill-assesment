const logger = require("../../../config/logger");
const { verifyPassword } = require("../../../services/auth.service");
const { prisma } = require('../../../db/client');
const ApiError = require("../../../utilities/apiErrors");
const httpStatus = require('http-status');


const loginUserWithEmailAndPassword = async (email, password) => {
  logger.debug(`Attempting login for ${email}`);
  
  const user = await prisma.user.findUnique({ where: { email } });
  
  if (!user || user.isDeleted) {
    logger.warn(`Login failed: Email not found or deleted - ${email}`);
    throw new ApiError(httpStatus.UNAUTHORIZED, 'Incorrect email or password');
  }
  
  const isMatch = await verifyPassword(password, user.password);
  if (!isMatch) {
    logger.warn(`Login failed: Invalid password for ${email}`);
    throw new ApiError(httpStatus.UNAUTHORIZED, 'Incorrect email or password');
  }
  
  return user;
};


module.exports = { loginUserWithEmailAndPassword };