const httpStatus = require('http-status');
const { prisma } = require('../../../db/client');
const ApiError = require('../../../utilities/apiErrors'); 
const logger = require('../../../config/logger'); 
const { getNextSequence } = require('../../../utilities/sequenceGenerator'); 
const { hashPassword } = require('../../../services/auth.service');

const registerUser = async (userBody) => {
  // Check existence to throw a 400 Bad Request
  const existingUser = await prisma.user.findUnique({ where: { email: userBody.email } });
  if (existingUser) {
    logger.warn(`Registration attempt failed: Email ${userBody.email} already exists`);
    throw new ApiError(httpStatus.BAD_REQUEST, 'Email already taken');
  }

  try {
    // Atomically get the next sequential ID
    const seqId = await getNextSequence('user');
    const hashedPassword = hashPassword(userBody.password);

    const user = await prisma.user.create({
      data: {
        ...userBody,
        password: hashedPassword,
        seqId,
      },
    });

    logger.info(`Successfully created user ${user.id} with sequential ID ${user.seqId}`);
    return user;
  } catch (error) {
    logger.error(`Database error during user registration: ${error.message}`);
    throw error;
  }
};

module.exports = { registerUser };