const crypto = require('crypto');
const httpStatus = require('http-status');
const { prisma } = require('../db/client');
const ApiError = require('../utilities/apiErrors');
const config = require('../config/config');
const logger = require('../config/logger');
const { responseMessages, auditActions, systemConfig } = require('../config/constants');
const jwt = require('jsonwebtoken');
const { tokenTypes } = require('../config/enums');
/**
 * Generates a cryptographically strong random token
 */
const generateOpaqueToken = () => {
  return crypto.randomBytes(systemConfig.TOKEN_LENGTH).toString('hex');
};

/**
 * Hashes an opaque token for secure database storage
 */
const hashToken = (token) => {
  return crypto.createHash(systemConfig.HASH_ALGORITHM).update(token).digest('hex');
};

/**
 * Creates a new secure session with an audit log record
 */
const createSecureSession = async (userId, ipAddress, userAgent) => {
  const refreshToken = generateOpaqueToken();
  const refreshTokenHash = hashToken(refreshToken);
  
  const expiresAt = new Date();
  expiresAt.setDate(expiresAt.getDate() + config.jwt.refreshExpirationDays);

  logger.debug(`Initiating secure session creation for User ID: ${userId}`);

  try {
    await prisma.$transaction(async (tx) => {
      await tx.session.create({
        data: { userId, refreshToken: refreshTokenHash, ipAddress, userAgent, expiresAt },
      });

      await tx.auditLog.create({
        data: { 
          userId, 
          action: auditActions.AUTH_LOGIN, 
          ipAddress, 
          userAgent, 
          metadata: { method: 'password' } 
        },
      });
    });

    logger.info(`Secure session successfully established for user: ${userId}`);
    return refreshToken;
  } catch (error) {
    logger.error(`Failed to create secure session for user ${userId}: ${error.message}`);
    throw error;
  }
};

/**
 * Implements Refresh Token Rotation (RTR) to mitigate token theft
 */
const rotateRefreshToken = async (rawRefreshToken, ipAddress, userAgent) => {
  const hashedToken = hashToken(rawRefreshToken);

  const session = await prisma.session.findFirst({
    where: { refreshToken: hashedToken },
  });

  // 1. Security Alert: Reuse Detection
  // If a valid hash is not found, it implies the token is invalid or has already been used (stolen).
  if (!session) {
    logger.error(`SECURITY ALERT: Potential token reuse or brute force attempt from IP: ${ipAddress}`);
    throw new ApiError(httpStatus.UNAUTHORIZED, responseMessages.auth.INVALID_TOKEN);
  }

  // 2. Lifecycle Check: Expiry and Validity
  if (!session.isValid || new Date() > session.expiresAt) {
    logger.warn(`Rejected rotation for expired/invalid session: ${session.id} (User: ${session.userId})`);
    await prisma.session.delete({ where: { id: session.id } });
    throw new ApiError(httpStatus.UNAUTHORIZED, responseMessages.auth.SESSION_EXPIRED);
  }

  const newRefreshToken = generateOpaqueToken();
  const newHash = hashToken(newRefreshToken);
  const newExpires = new Date();
  newExpires.setDate(newExpires.getDate() + config.jwt.refreshExpirationDays);

  try {
    const rotatedSession = await prisma.$transaction(async (tx) => {
      // Atomic Rotation: Revoke old session and create new one simultaneously
      await tx.session.delete({ where: { id: session.id } });
      
      const newSession = await tx.session.create({
        data: { userId: session.userId, refreshToken: newHash, ipAddress, userAgent, expiresAt: newExpires },
      });
      
      await tx.auditLog.create({
        data: { userId: session.userId, action: auditActions.AUTH_REFRESH, ipAddress, userAgent },
      });

      return newSession;
    });

    logger.info(`Refresh token rotated for user: ${session.userId}. New session: ${rotatedSession.id}`);
    return { newRefreshToken, userId: session.userId };
  } catch (error) {
    logger.error(`Critical failure during token rotation for user ${session.userId}: ${error.message}`);
    throw error;
  }
};

const generateAccessToken = (userId) => {
  const payload = {
    sub: userId,
    type: tokenTypes.ACCESS,
    iat: Math.floor(Date.now() / 1000),
  };
  return jwt.sign(payload, config.jwt.secret, {
    expiresIn: `${config.jwt.accessExpirationMinutes}m`,
  });
};

module.exports = {
  createSecureSession,
  rotateRefreshToken,
  hashToken,
  generateAccessToken
};