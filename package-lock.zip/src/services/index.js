const authService = require('./auth.service');
const tokenService = require('./token.service');

module.exports = {
  authService,
  tokenService,
};