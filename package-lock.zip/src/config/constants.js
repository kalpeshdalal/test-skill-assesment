const responseMessages = {
  auth: {
    LOGIN_SUCCESS: 'Login successful',
    LOGOUT_SUCCESS: 'Logout successful',
    REFRESH_SUCCESS: 'Token refreshed successfully',
    INVALID_TOKEN: 'Invalid or expired refresh token',
    SESSION_EXPIRED: 'Session has expired',
    UNAUTHORIZED: 'Unauthorized access',
  },
  rateLimit: {
    GLOBAL: 'Too many requests, please try again later.',
    AUTH_STRICT: 'Too many login attempts, please try again in 15 minutes.',
  },
  server: {
    INTERNAL_ERROR: 'Internal Server Error',
  }
};

const auditActions = {
  AUTH_LOGIN: 'AUTH_LOGIN',
  AUTH_LOGOUT: 'AUTH_LOGOUT',
  AUTH_REFRESH: 'AUTH_REFRESH',
  AUTH_FAILED: 'AUTH_FAILED',
  SENSITIVE_UPDATE: 'SENSITIVE_UPDATE', // e.g. Password change
};

// Only keep constants that are NOT environment dependent
const systemConfig = {
  TOKEN_LENGTH: 40,        // Byte length for crypto
  HASH_ALGORITHM: 'sha256' // Algorithm for token hashing
};

module.exports = {
  responseMessages,
  auditActions,
  systemConfig,
};