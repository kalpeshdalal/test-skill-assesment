const winston = require('winston');
const config = require('./config');
const path = require('path');

// Custom error formatting
const enumerateErrorFormat = winston.format((info) => {
  if (info instanceof Error) {
    Object.assign(info, { message: info.stack });
  }
  return info;
});

// Define log filename and log level based on environment
const logFilename = path.join(__dirname, '../../logs/app.log'); // Senior Tip: Put logs in a folder, not root
const logLevel = config.env === 'development' ? 'debug' : 'info';

const logger = winston.createLogger({
  level: logLevel,
  format: winston.format.combine(
    winston.format.timestamp({ format: 'YYYY-MM-DD HH:mm:ss' }),
    enumerateErrorFormat(),
    config.env === 'development' ? winston.format.colorize() : winston.format.uncolorize(),
    winston.format.splat(),
    winston.format.printf(({ timestamp, level, message, ...metadata }) => {
      // Senior Tip: Cleaner metadata handling
      const metaString = Object.keys(metadata).length
        ? `\n${JSON.stringify(metadata, null, 2)}` 
        : '';
      return `[${timestamp}] ${level}: ${message} ${metaString}`;
    })
  ),
  transports: [
    new winston.transports.Console({
      stderrLevels: ['error'],
    }),
  ],
});

// Production Optimization: Only write to file in Prod/Staging to save I/O in dev
if (config.env !== 'development') {
  logger.add(new winston.transports.File({ 
    filename: logFilename,
    maxsize: 5242880, 
    maxFiles: 5,
  }));
}

module.exports = logger;