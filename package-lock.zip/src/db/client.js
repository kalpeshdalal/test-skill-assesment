const { PrismaClient } = require('@prisma/client');
const config = require('../config/config');
const logger = require('../config/logger');

const globalForPrisma = global;

// 1. Pass 'datasourceUrl' explicitly
const prisma = globalForPrisma.prisma || new PrismaClient({
  datasourceUrl: config.databaseUrl, 
  log: config.env === 'development' ? ['query', 'error', 'warn'] : ['error'],
});

if (config.env !== 'production') globalForPrisma.prisma = prisma;

const connectDB = async () => {
  try {
    await prisma.$connect();
    logger.info('PostgreSQL connection established via Prisma.');
  } catch (error) {
    logger.error('Unable to connect to the database:', error);
    process.exit(1);
  }
};

module.exports = {
  prisma,
  connectDB
};