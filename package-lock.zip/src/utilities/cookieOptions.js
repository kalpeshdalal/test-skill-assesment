const config = require('../config/config');

/**
 * centralized cookie configuration
 * @returns {import('express').CookieOptions}
 */
const getRefreshTokenCookieOptions = () => {
  return {
    httpOnly: true,                        // Prevent XSS (JS cannot read this)
    secure: config.env === 'production',   // HTTPS only in Prod
    sameSite: 'strict',                    // CSRF Protection
    path: '/v1/auth/refresh-tokens',       // Security+: Cookie ONLY sent to refresh endpoint
    expires: new Date(
      Date.now() + config.jwt.refreshExpirationDays * 24 * 60 * 60 * 1000
    ),
  };
};

module.exports = {
  getRefreshTokenCookieOptions,
};