const sendResponse = (res, statusCode, data, message = null) => {
  const success = statusCode >= 200 && statusCode < 300;
  
  const response = {
    code: statusCode,
    success, 
    message: message || (success ? 'Success' : 'Error'),
    data: data || null,
  };

  res.status(statusCode).json(response);
};

module.exports = sendResponse;