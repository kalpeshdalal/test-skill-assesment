const express = require("express");
const cors = require("cors");
const httpStatus = require("http-status");
const config = require("./config/config");
const morgan = require("./config/morgan");
const helmet = require("helmet");
const compression = require("compression");
const cookieParser = require('cookie-parser');
const passport = require("passport");
const xss = require("xss-clean");
const { jwtStrategy } = require("./config/jwtStrategy");
const ApiError = require("./utilities/apiErrors");
const { errorConverter, errorHandler } = require("./middlewares/error");
const { globalLimiter } = require("./middlewares/rateLimiter");
const routes = require("./routes");

const app = express();

// 1. Security & Logging
app.use(helmet());
if (config.env !== "test") {
  app.use(morgan.successHandler);
  app.use(morgan.errorHandler);
}

// 2. Global Rate Limiter (Production Only)
if (config.env === 'production') {
  app.use(globalLimiter);
}

// 3. Parsing
app.use(express.json());
app.use(express.urlencoded({ extended: true }));
app.use(cookieParser())

// 4. Sanitization
app.use(xss());
app.use(compression());

// 5. CORS
app.use(cors({ origin: config.cors.origin }));

// 6. Authentication (Stateless JWT)
app.use(passport.initialize());
passport.use("jwt", jwtStrategy);

// 7. Routes
app.use("/v1", routes);

// 8. Error Handling
app.use((req, res, next) => next(new ApiError(httpStatus.NOT_FOUND, "Not Found")));
app.use(errorConverter);
app.use(errorHandler);

module.exports = app;