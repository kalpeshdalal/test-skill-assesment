-- AlterTable
ALTER TABLE "tokens" ADD COLUMN     "access_token_hash" TEXT;
