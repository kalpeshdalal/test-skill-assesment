/*
  Warnings:

  - A unique constraint covering the columns `[seq_id]` on the table `users` will be added. If there are existing duplicate values, this will fail.
  - Added the required column `seq_id` to the `users` table without a default value. This is not possible if the table is not empty.

*/
-- AlterTable
ALTER TABLE "users" ADD COLUMN     "seq_id" INTEGER NOT NULL;

-- CreateTable
CREATE TABLE "sequences" (
    "id" TEXT NOT NULL,
    "model_name" TEXT NOT NULL,
    "current" INTEGER NOT NULL DEFAULT 0,
    "updated_at" TIMESTAMP(3) NOT NULL,

    CONSTRAINT "sequences_pkey" PRIMARY KEY ("id")
);

-- CreateIndex
CREATE UNIQUE INDEX "sequences_model_name_key" ON "sequences"("model_name");

-- CreateIndex
CREATE UNIQUE INDEX "users_seq_id_key" ON "users"("seq_id");
