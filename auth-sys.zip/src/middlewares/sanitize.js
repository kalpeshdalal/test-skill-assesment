const cleanData = (data) => {
  if (Array.isArray(data)) {
    return data.map(cleanData);
  }

  if (data instanceof Date) {
    return data;
  }

  if (data !== null && typeof data === 'object') {
    return Object.keys(data).reduce((acc, key) => {
      if (key === 'password') {
        return acc;
      }
      acc[key] = cleanData(data[key]);
      return acc;
    }, {});
  }

  return data;
};

const sanitizeResponse = (req, res, next) => {
  const originalJson = res.json;

  res.json = function (body) {
    // 1. Clean the body
    const sanitizedBody = cleanData(body);
    
    // 2. Send the cleaned body using the original method
    return originalJson.call(this, sanitizedBody);
  };

  next();
};

module.exports = sanitizeResponse;