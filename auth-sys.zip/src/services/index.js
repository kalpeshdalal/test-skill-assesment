const tokenService = require('./token.service');

module.exports = {
  tokenService,
};