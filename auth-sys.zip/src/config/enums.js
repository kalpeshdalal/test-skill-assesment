// Centralized Enums
const tokenTypes = {
  ACCESS: 'ACCESS',           
  REFRESH: 'REFRESH',         
  RESET_PASSWORD: 'RESET_PASSWORD',
  VERIFY_EMAIL: 'VERIFY_EMAIL',
};

const roles = {
  SUPER_ADMIN: 'SUPER_ADMIN', 
  ADMIN: 'ADMIN',             
  SUPERVISOR: 'SUPERVISOR',   
  USER: 'USER',               
};

const environments = {
  PRODUCTION: 'production',
  DEVELOPMENT: 'development',
  STAGING: 'staging',
  TEST: 'test',
};

module.exports = {
  tokenTypes,
  roles,
  environments,
};