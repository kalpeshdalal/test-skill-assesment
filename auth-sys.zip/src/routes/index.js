const express = require('express');
const authRoute = require('./auth.route'); 
const usersRoute = require('./user.route');
const sendResponse = require('../utilities/responseHandler');
const httpStatus = require('http-status');

const router = express.Router();

const defaultRoutes = [
  {
    path: '/auth',
    route: authRoute,
  },
  {
    path: '/users',
    route: usersRoute,
  }
];

defaultRoutes.forEach((route) => {
  router.use(route.path, route.route);
});

router.get('/health', (req, res) => {
  sendResponse(res, httpStatus.OK, { timestamp: new Date() }, 'Health Check Passed');
});

module.exports = router;