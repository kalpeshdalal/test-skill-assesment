const httpStatus = require('http-status');
const { prisma } = require('../../../db/client');
const ApiError = require('../../../utilities/apiErrors');
const logger = require('../../../config/logger');
const { getNextSequence } = require('../../../utilities/sequenceGenerator');
const { hashPassword } = require('./auth.service'); 
const { responseMessages } = require('../../../config/constants');

const registerUser = async (userBody) => {
  try {
    const seqId = await getNextSequence('user');
    const hashedPassword = await hashPassword(userBody.password); 

    const user = await prisma.user.create({
      data: {
        ...userBody,
        password: hashedPassword,
        seqId,
      },
    });

    logger.info(`Successfully created user ${user.id}`);
    return user;
  } catch (error) {
    if (error.code === 'P2002' && error.meta?.target) {
      if (error.meta.target.includes('email')) {
        throw new ApiError(httpStatus.BAD_REQUEST, responseMessages.auth.EMAIL_ALREADY_REGISTERED);
      }
      if (error.meta.target.includes('mobile')) {
        throw new ApiError(httpStatus.BAD_REQUEST, responseMessages.auth.MOBILE_ALREADY_REGISTERED);
      }
    }
    
    logger.error(`Database error during user registration: ${error.message}`);
    throw error;
  }
};

module.exports = { registerUser };