const tokenService = require('../../../services/token.service');
const jwt = require('jsonwebtoken');

/**
 * Single Logout: Revoke current refresh token and blacklist current access token
 */
const logoutUser = async (refreshToken, accessToken, ipAddress, userAgent) => {
  // 1. Blacklist Access Token
  if (accessToken) {
    const isBlacklisted = await tokenService.isTokenBlacklisted(accessToken);
    if (!isBlacklisted) {
      const decoded = jwt.decode(accessToken);
      if (decoded) {
        const expiresAt = new Date(decoded.exp * 1000);
        await tokenService.blacklistToken(accessToken, decoded.sub, expiresAt);
      }
    }
  }

  // 2. Revoke specific Refresh Token
  if (refreshToken) {
    await tokenService.revokeRefreshTokens(refreshToken, ipAddress, userAgent);
  }
};

/**
 * Logout All: Revoke all sessions and blacklist all associated access tokens
 */
const logoutAllDevices = async (userId, accessToken, ipAddress, userAgent) => {
  // 1. Blacklist the CURRENT Access Token immediately
  if (accessToken) {
    const isBlacklisted = await tokenService.isTokenBlacklisted(accessToken);
    if (!isBlacklisted) {
      const decoded = jwt.decode(accessToken);
      if (decoded) {
        const expiresAt = new Date(decoded.exp * 1000);
        await tokenService.blacklistToken(accessToken, userId, expiresAt);
      }
    }
  }

  // 2. Revoke ALL sessions (Logic in token service blacklists the rest)
  await tokenService.revokeAllUserSessions(userId, ipAddress, userAgent);
};

module.exports = {
  logoutUser,
  logoutAllDevices,
};