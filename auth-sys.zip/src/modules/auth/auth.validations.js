const Joi = require('joi');
const { systemConfig } = require('../../config/constants');

const passwordPattern = /^(?=.*[a-z])(?=.*[A-Z])(?=.*\d)(?=.*[@$!%*?&])[A-Za-z\d@$!%*?&]{8,}$/;

const register = {
  body: Joi.object().keys({
    email: Joi.string().required().email(),
    password: Joi.string().required().pattern(passwordPattern).messages({
      'string.pattern.base': 'Password must contain at least one uppercase letter, one lowercase letter, one number, and one special character',
      'string.min': 'Password must be at least 8 characters long'
    }),
    fullName: Joi.string().required(),
    mobile: Joi.string().optional(),
    designation: Joi.string().optional(),
  }),
};

const login = {
  body: Joi.object().keys({
    email: Joi.string().required(),
    password: Joi.string().required(),
  }),
};

const refreshTokens = {
  cookies: Joi.object().keys({
    // Hex string is 2 chars per byte
    refreshToken: Joi.string().required().length(systemConfig.TOKEN_LENGTH * 2),
  }).unknown(true),
};

const logout = {
  cookies: Joi.object().keys({
    refreshToken: Joi.string().required().length(systemConfig.TOKEN_LENGTH * 2),
  }).unknown(true),
  headers: Joi.object().keys({
    authorization: Joi.string().required().pattern(/^Bearer\s[\w-]*\.[\w-]*\.[\w-]*$/),
  }).unknown(true),
};

module.exports = {
  register,
  login,
  refreshTokens,
  logout
};