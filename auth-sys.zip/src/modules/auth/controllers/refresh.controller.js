const httpStatus = require('http-status');
const catchAsync = require('../../../utilities/catchAsync');
const refreshService = require('../services/refresh.service');
const { responseMessages } = require('../../../config/constants');
const { getRefreshTokenCookieOptions } = require('../../../utilities/cookieOptions');
const sendResponse = require('../../../utilities/responseHandler');

const refreshTokens = catchAsync(async (req, res) => {
  const currentRefreshToken = req.cookies.refreshToken;

  // Service will throw if token is invalid/missing
  const { accessToken, newRefreshToken } = await refreshService.refreshAuth(
    currentRefreshToken,
    req.ip,
    req.headers['user-agent']
  );

  // Set new cookie
  res.cookie('refreshToken', newRefreshToken, getRefreshTokenCookieOptions());

  // Return new access token
  sendResponse(
    res,
    httpStatus.OK,
    { accessToken },
    responseMessages.auth.REFRESH_SUCCESS
  );
});

module.exports = { refreshTokens };