const httpStatus = require('http-status');
const catchAsync = require('../../../utilities/catchAsync');
const pick = require('../../../utilities/pick');
const registerService = require('../services/register.service');
const { sendAuthResponse } = require('../services/auth.service');
const logger = require('../../../config/logger');
const { responseMessages } = require('../../../config/constants');

const register = catchAsync(async (req, res) => {
  const userBody = pick(req.body, ['email', 'password', 'fullName', 'mobile', 'designation']);
  
  logger.debug(`Registering new user: ${userBody.email}`);

  const user = await registerService.registerUser(userBody);
  
  await sendAuthResponse(req, res, user, httpStatus.CREATED, responseMessages.auth.USER_REGISTERED);
});

module.exports = { register };