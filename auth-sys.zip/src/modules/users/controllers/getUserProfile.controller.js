
const httpStatus = require('http-status');
const catchAsync = require('../../../utilities/catchAsync');
const sendResponse = require('../../../utilities/responseHandler');
const userService = require('../services/getUserProfile.service');
const pick = require('../../../utilities/pick');

const getProfile = catchAsync(async (req, res) => {
    const { id } = pick(req.user, ["id"]);

    const user = await userService.getUserById(id);

    sendResponse(res, httpStatus.OK, user, 'Profile retrieved successfully');
});

module.exports = {
    getProfile,
};