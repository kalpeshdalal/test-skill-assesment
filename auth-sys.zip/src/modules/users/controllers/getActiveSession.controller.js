const httpStatus = require('http-status');
const catchAsync = require('../../../utilities/catchAsync');
const sendResponse = require('../../../utilities/responseHandler');
const sessionService = require('../services/getActiveSession.service');
const pick = require('../../../utilities/pick');
const { responseMessages } = require('../../../config/constants');

const getActiveSessions = catchAsync(async (req, res) => {
  const { id } = pick(req.user, ['id']);

  const sessions = await sessionService.getUserActiveSessions(id);

  sendResponse(
    res,
    httpStatus.OK,
    sessions,
    responseMessages.auth.SESSIONS_FETCHED
  );
});

module.exports = {
  getActiveSessions,
};