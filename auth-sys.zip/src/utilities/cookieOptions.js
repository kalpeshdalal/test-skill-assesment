const config = require('../config/config');

/**
 * centralized cookie configuration
 * @returns {import('express').CookieOptions}
 */
const getRefreshTokenCookieOptions = () => {
  return {
    httpOnly: true,
    secure: config.env === 'production',
    sameSite: 'strict',
    path: '/v1/auth',
    expires: new Date(
      Date.now() + config.jwt.refreshExpirationDays * 24 * 60 * 60 * 1000
    ),
  };
};

module.exports = {
  getRefreshTokenCookieOptions,
};