/**
 * Extracts the Bearer token from the request headers.
 * @param {Object} req - Express request object
 * @returns {string|null} - The extracted token or null
 */
const extractToken = (req) => {
  if (
    req.headers.authorization &&
    req.headers.authorization.split(' ')[0] === 'Bearer'
  ) {
    return req.headers.authorization.split(' ')[1];
  }
  return null;
};

module.exports = {
  extractToken,
};