const { prisma } = require('../db/client');

/**
 * Returns the next sequential integer for a model (1, 2, 3...)
 * @param {string} modelName - The identifier (e.g., "user")
 * @param {Object} [tx] - Optional transaction client
 */
const getNextSequence = async (modelName, tx = prisma) => {
  const sequence = await tx.sequence.upsert({
    where: { modelName },
    update: { current: { increment: 1 } },
    create: { modelName, current: 1 },
  });

  return sequence.current;
};

module.exports = {
  getNextSequence
};